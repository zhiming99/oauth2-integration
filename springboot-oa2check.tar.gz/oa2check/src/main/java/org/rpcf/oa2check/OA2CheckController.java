package org.rpcf.oa2check;

import java.io.IOException; 
import java.io.PrintWriter;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.rpcf.rpcbase.*;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;



@RestController
public class OA2CheckController{

    private final HashMap<String, USER_INFO> m_mapUserInfo;
    private OA2proxysvr m_oRpcSvr;
    public OA2CheckController() throws IOException
    {
        m_mapUserInfo = new HashMap<>();
        JRetVal jret = mainsvr.createSvrInst();
        if( jret.SUCCEEDED() )
        {
            m_oRpcSvr = ( OA2proxysvr )jret.getAt( 0 );
            m_oRpcSvr.controller = this;
        }
        else
        {
            System.out.println(
                "Error create OA2proxysvr failed " +
                jret.getError() );
        }
    }

    public synchronized USER_INFO getUserInfo( String strSess )
    {
        return m_mapUserInfo.get( strSess );
    }

    public synchronized USER_INFO removeUserInfo( String strSess )
    {
        return m_mapUserInfo.remove( strSess );
    }

    public synchronized void addUserInfo( String strSess, USER_INFO ui )
    {
        m_mapUserInfo.put(strSess, ui);
    }

    public synchronized int getUserCount()
    {
        return m_mapUserInfo.size();
    }

    @RequestMapping("/oauth2/logined")
    public void Logined(HttpServletRequest request, HttpServletResponse response) throws IOException {
	     Authentication a = SecurityContextHolder.getContext().getAuthentication();
         OAuth2User principal = ((OAuth2AuthenticationToken) a).getPrincipal();
         String strName = principal.getAttribute( "name" );
         HttpSession sess = request.getSession();
         SessionBindingListener oBinding = new SessionBindingListener(this);
         String strSession = sess.getId();
         sess.setAttribute(strSession, oBinding);

         response.addHeader( "Content-Type", "text/html; charset=utf-8" );
         PrintWriter oWriter = response.getWriter();
         oWriter.println( "<!DOCTYPE html>" );
         oWriter.println( "<body>" );
         oWriter.println( strName + " logined @" + strSession ); 
         oWriter.println( "<a href=\"/rpcf/HelloWorld.html\">continue to rpc-frmwrk</a>" );
         oWriter.println( "</body>" );
         oWriter.println( "</html>" );
    }

	@RequestMapping("/user")
	public Map<String, Object> user(@AuthenticationPrincipal OAuth2User principal) {
        
        System.out.println( "entering /user " );
        if( principal == null )
        {
            return Collections.singletonMap("name", "InvalidUser" );
        }
        System.out.println( principal );
		return Collections.singletonMap("name", principal.getAttribute("name"));
	}
}
