package org.rpcf.oa2check;

import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class SessionListener implements HttpSessionListener {

    @Override
    public void sessionCreated(HttpSessionEvent se) {
        String sessionId = se.getSession().getId();
        String strNow = SessionBindingListener.FormatNow();
        System.out.println( strNow + " " + sessionId + " created" );
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        String sessionId = se.getSession().getId();
        String strNow = SessionBindingListener.FormatNow();
        System.out.println( strNow + " " + sessionId + " destroyed" );
    }
}
