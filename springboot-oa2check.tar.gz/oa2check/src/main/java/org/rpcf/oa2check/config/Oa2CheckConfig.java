package org.rpcf.oa2check.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;

import org.springframework.http.HttpStatus;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import static org.springframework.security.config.Customizer.withDefaults;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;

@Configuration
@EnableWebSecurity
public class Oa2CheckConfig {
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        System.out.println( "hello" );
        SimpleUrlAuthenticationFailureHandler handler = new SimpleUrlAuthenticationFailureHandler("/");
        http.csrf(c ->c.csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()));
        http.authorizeHttpRequests(requests->
            requests.requestMatchers( "/",
            "/index.html", "/webjars/**",
            "/error" )
            .permitAll().anyRequest().authenticated()
            )
        .exceptionHandling((e) -> {
            e.authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED));
            ;})
        .logout( (l)->{
            l.logoutSuccessUrl("/").permitAll();
            })
        .oauth2Login((o) ->{
            o.failureHandler((request, response, exception) -> {
                    System.out.println( "failureHandler :" + exception.getMessage());
                    request.getSession().setAttribute("error.message", exception.getMessage());
                    handler.onAuthenticationFailure(request, response, exception);
                ;}
            );
            o.successHandler( new OAuth2SuccessHandler());
        })
        ;
        return http.build();
    }
}
