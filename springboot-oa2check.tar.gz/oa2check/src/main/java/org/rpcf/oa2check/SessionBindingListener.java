package org.rpcf.oa2check;
import jakarta.servlet.http.HttpSessionBindingEvent;
import jakarta.servlet.http.HttpSessionBindingListener;
import java.text.SimpleDateFormat;
import jakarta.servlet.http.HttpSession;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.OAuth2User;
import java.time.*;

public class SessionBindingListener implements HttpSessionBindingListener{
    private OA2CheckController controller;

    public static String FormatNow()
    {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            .format( new java.util.Date() );
    }

    public SessionBindingListener( OA2CheckController oCtrl )
    { controller = oCtrl; }

    public void setController( OA2CheckController oCtrl )
    { controller = oCtrl; }

    public OA2CheckController getController()
    { return controller; }

    @Override
    public void valueBound(HttpSessionBindingEvent event) {
        String strNow = FormatNow();
        HttpSession sess = event.getSession();
        String strSess = sess.getId();

	    Authentication a = SecurityContextHolder.getContext().getAuthentication();
        OAuth2User principal = ((OAuth2AuthenticationToken) a).getPrincipal();

        System.out.println( strNow + " User session started: " + "@" + strSess );

        // build the USER_INFO struct
        // make sure all USER_INFO fields are
        // initialized, otherwise, the serialization
        // may fail.
        USER_INFO ui = new USER_INFO();
        ui.strUserId = principal.getAttribute( "name" );
        if( ui.strUserId == null )
            ui.strUserId = "";
        ui.strEmail = principal.getAttribute( "email" );
        if( ui.strEmail == null )
            ui.strEmail = "";
        ui.strUserName="";
        Instant exp = principal.getAttribute( "exp" );
        TIMESTAMP ts = new TIMESTAMP();
        ts.tv_sec = exp.toEpochMilli();
        ui.tsExpireTime = ts;

        controller.addUserInfo( strSess, ui );
        System.out.println( principal );
        System.out.println( ui );
    }

    @Override
    public void valueUnbound(HttpSessionBindingEvent event) {
        String strNow = FormatNow();
        HttpSession sess = event.getSession();
        String strSess = sess.getId();
        System.out.println( strNow + " User session ended: " + "@" + strSess );
        controller.removeUserInfo( strSess );
    }
}
