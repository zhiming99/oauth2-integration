package org.rpcf.oa2check.config;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Cookie;
import java.io.IOException;

public class OAuth2SuccessHandler implements AuthenticationSuccessHandler {
     @Override
     public void onAuthenticationSuccess(
        HttpServletRequest request,
        HttpServletResponse response,
        Authentication authentication) throws IOException {
        String targetUrl = "/oauth2/logined";
        String strSession = request.getSession().getId();
        // cookie for rpc-frmwrk
        Cookie rpcfCookie = new Cookie("rpcf_code", strSession );
        rpcfCookie.setPath( "/" );
        response.addCookie( rpcfCookie );
        // redirect the login success page to targetUrl
        response.sendRedirect(targetUrl);
     }
}
