how to start:

0. check to make sure 'eth0' is bind to 172.17.0.2 because the system is
currently configured to 172.17.0.2. This system is built with sdkman, gradle and springboot.

0.1 start OAuth2 server on another docker with address 172.17.0.3.

1. 'cd /root'

2  run 'dbus-run-session screen' or 'dbus-run-session tmux' because we will use several consoles to start and monitor mulitple tasks.

3. start nginx by running 'nginx'

4. kill all the running java vm. Start spring application "oa2check" by 'pushd oa2check; gradle bootRun'

5. open another window and run rpcrouter by 'rpcrouter -adr 2'

6. open a third window and run 'CLASSPATH=/usr/lib/x86_64-linux-gnu/rpcf/rpcbase.jar:/usr/share/java/commons-cli.jar;cd ~/hellowldsvr;java org.rpcf.HelloWorld.mainsvr'

8. Now the rpc-frmwrk with spring boot oauth2 authorization are ready to go.

9. open a browser on your host machine. and enter the url 'http://172.17.0.2' and follow the link and oauth2 process till seeing the hellowld page.

10. open the browser debugger's console window to check if the text 'server response is Hello, Proxy!' is shown.

More detail:
system component:
web server: nginx
app server: springboot
app framework: springboot

rpc daemon: rpcrouter
rpc server: org.rpcf.HelloWorld.mainsvr

system connetivity:

                               /---------------------------------->spring oauth2 security<================\
                               |                                                                          |
       OAuth2 req              V                                                                          |
nginx------------->springboot------->springboot app( oa2check ) <=========> oauth2 provider( 172.17.0.3 ) |
      |   A                           A                                                                   |
      |   |                           |                                                     rpc req/resp  V
      |   --------------------------------------------->JavaScript from HelloWorld.html<=======================>browser
      |                               |
      |                               | user login
      |                               |
      \--------------------------->rpcrouter
                                      |
                                      V
                         org.rpcf.HelloWorld.mainsvr

for tutorial purpose, the traffics are using http instead https, so that you can use wireshark to monitor the traffic.
To turn on https:
0. kill all the running servers.
0.1 make sure you have had springboot running with https enabled.
1. Replace the url in application.properties from http to https
2. Create a new installation package on your development host with rpcfg.py with the following settings :
	. On 'connection page': check WebSocket ( SSL will also be enabled )
	. On 'connection page': set WebSocket-URL to https://172.17.0.2/chat
	. On 'Security page' :  set SSL Files, or press 'generate self-signed keys' for auto-setup.
	. On 'Security page' :  check Installer option 'WS Installer'. Make sure you have installed the nginx on your box.
	. On 'Security page' :  set 'Auth Mech' to 'OAuth2'
3. press 'Installer' button at the bottom on 'rpcfg.py' dialog, a installer will be generated, for example, instsvr-o-2024-08-05-60-1.sh.
3. Backup the docker container's /etc/nginx/sites-available/rpcf_nginx.conf to rpcf_nginx.conf.http.
4. Install the installer package, instsvr-o-2024-08-05-60-1.sh in this case to the docker container.
5. copy the 'location' blocks in rpcf_nginx.conf.http back to the new SSL-enabled /etc/nginx/sites-available/rpcf_nginx.conf, and replace http with https.
6. Update the url in maincli.js from http to https.
7. After the update, change to '/root/helloworldsite' directory and run 'make release'
8. then run 'cp -r HelloWorld.html HelloWorlddesc.json dist /var/www/html/rpcf/'
10. finally run 'nginx -s reload' to update the settings.
11. Jump to the begining of this article and start all the servers.
