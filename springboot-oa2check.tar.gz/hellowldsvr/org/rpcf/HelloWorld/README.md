### Introduction to the files:
* **maincli.java**, **mainsvr.java**: Containing defintion of `main()` method for client, as the main entry for client program and definition of `main()` function server program respectively. 
And you can make changes to the files to customize the program. The `ridlc` will not touch them if they exist in the project directory. When it runs again, it puts the newly generated code to `mainxxx.java.new` files instead.

* **HelloWorldSvcsvr.java**, **HelloWorldSvccli.java**: Containing the declarations and definitions of all the server/client side methods that need to be implemented by you, mainly the request/event handlers, for service `HelloWorldSvc`.
And you need to make changes to the files to implement the functionality for server/client. The `ridlc` will not touch them if they exist in the project directory. When it runs again, it puts the newly generated code to `HelloWorldSvcxxx.java.new` files instead.

* *HelloWorldSvcsvrbase.java*, *HelloWorldSvcclibase.java* : Containing the declarations and definitions of all the server/client side utilities and helpers for the interfaces of service `HelloWorldSvc`.
And please don't edit them, since they will be overwritten by next run of `ridlc` without backup.

* *StructFactory.java*: Containing the definition of struct factory declared and referenced in the ridl file.
And please don't edit it, since they will be overwritten by next run of `ridlc` without backup.

* *HelloWorlddesc.json*: Containing the configuration parameters for all the services declared in the ridl file
And please don't edit it, since they will be overwritten by next run of `ridlc` or synccfg.py without backup.

* *driver.json*: Containing the configuration parameters for all the ports and drivers
And please don't edit it, since they will be overwritten by next run of `ridlc` or synccfg.py without backup.

* *Makefile*: The Makefile will just synchronize the configurations with the local system settings. And it does nothing else.
And please don't edit it, since it will be overwritten by next run of `ridlc` and synccfg.py without backup.

* *DeserialMaps*, *DeserialArrays*, *JavaSerialBase.java*, *JavaSerialHelperS.java*, *JavaSerialHelperP.java*: Containing the utility classes for serializations.
And please don't edit it, since they will be overwritten by next run of `ridlc`.

* *synccfg.py*: a small python script to synchronous settings with the system settings, just ignore it.

* **run:** you can run `java org.rpcf.HelloWorld.mainsvr` and `java org.rpcf.HelloWorld.maincli` to start the server and client respectively. Also make sure to run `make` to update the configuration files, that is, the `HelloWorlddesc.json` and `driver.json`.

**Note 1**: the files in bold text need your further implementation. And files in italic text do not. And of course, you can still customized the italic files, but be aware they will be rewritten after running RIDLC again.

**Note 2**: Please refer to [this link](https://github.com/zhiming99/rpc-frmwrk#building-rpc-frmwrk) for building and installation of RPC-Frmwrk
