### Introduction to the files:
* **maincli.js**: Containing creation of the iomanager and client objects, andstarting the client objects for rpc communications
And you can make changes to the files to customize the program. The `ridlc` will not touch them if they exist in the project directory, when it runs again, and put the newly generated code to `maincli.js.new`.

* **HelloWorldSvccli.js**: Containing the declarations and definitions of all the client side methods that need to be implemented by you, mainly the request/event handlers, for service `HelloWorldSvc`.
And you need to make changes to the files to implement the business logics for client. The `ridlc` will not touch them if they exist in the project directory, when it runs again, and put the newly generated code to `HelloWorldSvccli.js.new`.

* *HelloWorldstructs.js*: Containing all the declarations of the struct classes declared in the ridl, with serialization methods implemented.
And please don't edit it, since they will be overwritten by `ridlc` without auto-backup.

* *HelloWorlddesc.json*: Containing the configuration parameters for all the services declared in the ridl file
And please don't edit it, since they will be overwritten by `ridlc` and synccfg.py without backup.

* *driver.json*: Containing the configuration parameters for all the ports and drivers
And please don't edit it, since they will be overwritten by `ridlc` and synccfg.js without backup.

* *Makefile*: The Makefile has 3 targets, `debug`, `release`, and `update`.`debug` and `release` will package the project to the `dist` directory. **So the `dist` directory, `HelloWorld.html`, and `HelloWorlddesc.json` are the file set to deploy to the web server.** The target 'update' will update the content of the json files in this directory with system settings.
And please don't edit it, since it will be overwritten by `ridlc` and synccfg.py without backup.

* *webpack.config.js*: the file is used by webpack to pack all the stuffs to a singlejs file 'HelloWorld.js' for deployment on the web server
And please don't edit it, since it will be overwritten by `ridlc` without backup.

* *HelloWorld.html*: This is a sample html file, to demonstrate how the webpage or external caller interact with the client object.
And if this file is already present, the ridlc will generate the new sample html to the `.new` file next time

* *HelloWorldSvcclibase.js* : Containing the declarations and definitions of all the client side utilities and helpers for the interfaces of service `HelloWorldSvc`.
And please don't edit them, since they will be overwritten by `ridlc` without backup.

* *synccfg.py*: a small python script to synchronous settings with the system settings, just ignore it.

**Note 1**: the files in bold text need your further implementation. And files in italic text do not. And of course, you can still customized the italic files, but be aware they will be rewritten after running RIDLC again.

**Note 2**: Please refer to [this link](https://github.com/zhiming99/rpc-frmwrk#building-rpc-frmwrk)for building and installation of RPC-Frmwrk
